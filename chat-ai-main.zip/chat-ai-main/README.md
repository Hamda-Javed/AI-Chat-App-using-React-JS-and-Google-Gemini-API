# Chat - AI

AI Chat App using Generative Language Client API

[chat-ai](https://ai.visheshpandey.com)

## Setup Procedure

- Copy .env.example to .env
- Get API key from: [api-key](https://aistudio.google.com/app/apikey)
- `npm install`
- `npm run dev`
